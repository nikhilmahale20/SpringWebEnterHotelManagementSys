<%@ page import="org.example.entity.Customer" %>
<%@ page import="org.example.enums.Role" %>

<%
    Customer customer =
            (Customer) session.getAttribute(
                    "loggedInCustomer"
            );

    if(customer == null ||
            customer.getRole() != Role.ADMIN){

        response.sendError(403);
        return;
    }
%>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
</head>
<body>

<h2>Admin Dashboard</h2>

<p>
    Welcome:
    <b><%= customer.getName() %></b>
</p>

<p>
    Role:
    <b><%= customer.getRole() %></b>
</p>

<hr>

<a href="${pageContext.request.contextPath}/add-room">
    Add Room
</a>

<br><br>

<a href="${pageContext.request.contextPath}/view-rooms">
    View Rooms
</a>

<br><br>

<a href="${pageContext.request.contextPath}/reports">
    View Reports
</a>

<br><br>

<a href="${pageContext.request.contextPath}/logout">
    Logout
</a>

</body>
</html>