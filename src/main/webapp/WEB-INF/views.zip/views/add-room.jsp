<%@ page contentType="text/html;charset=UTF-8"
         language="java"
         isELIgnored="false" %>

<html>
<head>
    <title>Add Room</title>
</head>

<body>

<h2>Add Room</h2>

<form action="add-room"
      method="post">

    Room Number:

    <input type="text"
           name="roomNumber"
           required>

    <br><br>

    Room Type:

    <select name="roomType">

        <option value="STANDARD">
            STANDARD
        </option>

        <option value="DELUXE">
            DELUXE
        </option>

        <option value="SUITE">
            SUITE
        </option>

    </select>

    <br><br>

    Price:

    <input type="number"
           name="price"
           required>

    <br><br>

    <button type="submit">

        Save Room

    </button>

</form>

<br><br>

<a href="rooms">

    View Rooms

</a>

</body>
</html>