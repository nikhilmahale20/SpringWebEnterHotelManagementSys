
<%@ page contentType="text/html;charset=UTF-8"
         language="java"
         isELIgnored="false" %>

<!DOCTYPE html>
<html>

<head>

    <title>Customer Dashboard</title>

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap"
          rel="stylesheet">

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:'Poppins',sans-serif;
        }

        body{
            display:flex;
            min-height:100vh;
            background:#f1f5f9;
        }

        /* SIDEBAR */

        .sidebar{
            width:260px;
            background:linear-gradient(180deg,#0f172a,#1e293b);
            color:white;
            padding:25px 20px;
            position:fixed;
            top:0;
            left:0;
            height:100%;
            box-shadow:4px 0 15px rgba(0,0,0,0.1);
        }

        .logo{
            text-align:center;
            margin-bottom:40px;
        }

        .logo h2{
            font-size:28px;
            font-weight:600;
            color:#60a5fa;
        }

        .menu a{
            display:flex;
            align-items:center;
            gap:12px;
            text-decoration:none;
            color:#cbd5e1;
            padding:15px;
            margin-bottom:10px;
            border-radius:12px;
            transition:0.3s ease;
            font-size:15px;
            font-weight:500;
        }

        .menu a:hover{
            background:#2563eb;
            color:white;
            transform:translateX(5px);
        }

        .menu a.active{
            background:#2563eb;
            color:white;
        }

        /* MAIN */

        .main{
            flex:1;
            margin-left:260px;
            padding:35px;
        }

        /* TOP SECTION */

        .top-bar{
            display:flex;
            justify-content:space-between;
            align-items:center;
            margin-bottom:30px;
        }

        .welcome-text h1{
            color:#0f172a;
            font-size:32px;
        }

        .welcome-text p{
            color:#64748b;
            margin-top:8px;
        }

        .profile-box{
            display:flex;
            align-items:center;
            gap:15px;
            background:white;
            padding:15px 20px;
            border-radius:15px;
            box-shadow:0 4px 12px rgba(0,0,0,0.08);
        }

        .profile-circle{
            width:55px;
            height:55px;
            border-radius:50%;
            background:#2563eb;
            color:white;
            display:flex;
            justify-content:center;
            align-items:center;
            font-size:22px;
            font-weight:bold;
        }

        /* USER CARD */

        .welcome-card{
            background:white;
            padding:30px;
            border-radius:20px;
            box-shadow:0 4px 14px rgba(0,0,0,0.08);
            margin-bottom:30px;
        }

        .welcome-card h2{
            color:#0f172a;
            margin-bottom:15px;
        }

        .info{
            display:flex;
            gap:40px;
            flex-wrap:wrap;
        }

        .info-box{
            background:#f8fafc;
            padding:20px;
            border-radius:15px;
            min-width:220px;
        }

        .info-box label{
            display:block;
            color:#64748b;
            font-size:14px;
            margin-bottom:8px;
        }

        .info-box p{
            font-size:18px;
            color:#0f172a;
            font-weight:600;
        }

        /* DASHBOARD CARDS */

        .cards{
            display:grid;
            grid-template-columns:
                    repeat(auto-fit,minmax(280px,1fr));
            gap:25px;
        }

        .card{
            background:white;
            padding:28px;
            border-radius:20px;
            box-shadow:0 4px 12px rgba(0,0,0,0.08);
            transition:0.3s ease;
        }

        .card:hover{
            transform:translateY(-8px);
        }

        .card h3{
            margin-bottom:15px;
            color:#0f172a;
        }

        .card p{
            color:#64748b;
            margin-bottom:18px;
        }

        .card a{
            display:inline-block;
            background:#2563eb;
            color:white;
            text-decoration:none;
            padding:12px 20px;
            border-radius:10px;
            transition:0.3s;
        }

        .card a:hover{
            background:#1d4ed8;
        }

        /* MOBILE */

        @media(max-width:768px){

            body{
                flex-direction:column;
            }

            .sidebar{
                width:100%;
                height:auto;
                position:relative;
                display:flex;
                flex-direction:column;
                padding:20px;
            }

            .menu{
                display:flex;
                overflow-x:auto;
                gap:10px;
            }

            .menu a{
                white-space:nowrap;
                margin-bottom:0;
            }

            .main{
                margin-left:0;
                padding:20px;
            }

            .top-bar{
                flex-direction:column;
                align-items:flex-start;
                gap:20px;
            }

            .welcome-text h1{
                font-size:26px;
            }

            .profile-box{
                width:100%;
            }

            .info{
                flex-direction:column;
                gap:15px;
            }

            .info-box{
                width:100%;
            }
        }

    </style>

</head>

<body>

<!-- SIDEBAR -->

<div class="sidebar">

    <div class="logo">
        <h2>🏨 HMS</h2>
    </div>

    <div class="menu">

        <a href="customer-dashboard"
           class="active">
            🏠 Dashboard
        </a>

        <a href="rooms">
            🛏 View Rooms
        </a>

        <a href="customer-bookings">
            📅 My Bookings
        </a>

        <a href="profile">
            👤 My Profile
        </a>

        <a href="${pageContext.request.contextPath}/my-payments">
            💳 My Payments
        </a>

        
        <a href="logout">
            🚪 Logout
        </a>

        <br><br>

    </div>

</div>

<!-- MAIN -->

<div class="main">

    <div class="top-bar">

        <div class="welcome-text">
            <h1>
                Welcome, ${customer.name} 👋
            </h1>

            <p>
                Manage your bookings and rooms easily
            </p>
        </div>

        <div class="profile-box">

            <div class="profile-circle">
                ${customer.name.charAt(0)}
            </div>

            <div>
                <strong>${customer.name}</strong>
                <br>
                <small>${customer.email}</small>
            </div>

        </div>

    </div>

    <!-- CUSTOMER INFO -->

    <div class="welcome-card">

        <h2>Your Information</h2>

        <div class="info">

            <div class="info-box">
                <label>Name</label>
                <p>${customer.name}</p>
            </div>

            <div class="info-box">
                <label>Email</label>
                <p>${customer.email}</p>
            </div>

            <div class="info-box">
                <label>Phone</label>
                <p>${customer.phone}</p>
            </div>

        </div>

    </div>

    <!-- CARDS -->

    <div class="cards">

        <div class="card">

            <h3>View Rooms</h3>

            <p>
                Browse available hotel rooms.
            </p>

            <a href="rooms">
                Explore Rooms
            </a>

        </div>
        <div class="card">

            <h3>My Payments</h3>

            <p>
                View payment history and invoices.
            </p>

            <a href="my-payments">
                View Payments
            </a>

        </div>

        <div class="card">

            <h3>My Bookings</h3>

            <p>
                Check your reservation history.
            </p>

            <a href="customer-bookings">
                View Bookings
            </a>

        </div>

        <div class="card">

            <h3>Account Status</h3>

            <p>
                Your account is active and verified.
            </p>

            <a href="#">
                Active ✅
            </a>

        </div>

    </div>

</div>

</body>
</html>

